import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { useRouterState } from "@tanstack/react-router";
import { ApiError } from "@/lib/api";
import {
  fetchCurrentAdminUser,
  loginAdmin,
  logoutAdmin,
  type AdminUser,
} from "@/lib/visemfood-api";
import { DEMO_ADMIN_CREDENTIALS } from "@/lib/runtime-config";

type LoginResult =
  | { ok: true }
  | { ok: false; error: string; status?: number };

type AdminAuthContextValue = {
  user: AdminUser | null;
  isAuthenticated: boolean;
  isHydrated: boolean;
  demoCredentials: {
    email: string;
    password: string;
  } | null;
  login: (credentials: { email: string; password: string }) => Promise<LoginResult>;
  logout: () => Promise<void>;
};

const AdminAuthContext = createContext<AdminAuthContextValue | null>(null);

export function AdminAuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AdminUser | null>(null);
  const [isHydrated, setIsHydrated] = useState(false);
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const shouldHydrateAdminSession = pathname.startsWith("/admin") || pathname === "/login";

  useEffect(() => {
    let cancelled = false;

    if (!shouldHydrateAdminSession) {
      setUser(null);
      setIsHydrated(true);
      return () => {
        cancelled = true;
      };
    }

    setIsHydrated(false);

    async function hydrateSession() {
      try {
        const nextUser = await fetchCurrentAdminUser();

        if (!cancelled) {
          setUser(nextUser);
        }
      } catch (error) {
        if (!cancelled) {
          if (error instanceof ApiError && [401, 419].includes(error.status)) {
            setUser(null);
          } else {
            setUser(null);
          }
        }
      } finally {
        if (!cancelled) {
          setIsHydrated(true);
        }
      }
    }

    void hydrateSession();

    return () => {
      cancelled = true;
    };
  }, [shouldHydrateAdminSession]);

  const value = useMemo<AdminAuthContextValue>(
    () => ({
      user,
      isAuthenticated: Boolean(user),
      isHydrated,
      demoCredentials: DEMO_ADMIN_CREDENTIALS,
      login: async ({ email, password }) => {
        try {
          const result = await loginAdmin({
            email: email.trim().toLowerCase(),
            password,
          });
          setUser(result.user);
          return { ok: true };
        } catch (error) {
          return {
            ok: false,
            error:
              error instanceof Error
                ? error.message
                : "Unable to sign in right now. Please try again shortly.",
            status: error instanceof ApiError ? error.status : undefined,
          };
        }
      },
      logout: async () => {
        try {
          await logoutAdmin();
        } catch {}

        setUser(null);
      },
    }),
    [isHydrated, user],
  );

  return <AdminAuthContext.Provider value={value}>{children}</AdminAuthContext.Provider>;
}

export function useAdminAuth() {
  const context = useContext(AdminAuthContext);

  if (!context) {
    throw new Error("useAdminAuth must be used within AdminAuthProvider");
  }

  return context;
}
