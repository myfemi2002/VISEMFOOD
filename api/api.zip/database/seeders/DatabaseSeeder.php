<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            PermissionSeeder::class,
            AdminUserSeeder::class,
            SiteSettingSeeder::class,
            CatalogSeeder::class,
            CateringPackageSeeder::class,
            OperationalSeeder::class,
        ]);
    }
}